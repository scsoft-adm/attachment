package com.devscb.filterapply;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;

public class TestController {
	@RequestMapping(value = "/test")
	public void test(HttpServletRequest request) {
	    System.out.println("controller called");
	}
}
