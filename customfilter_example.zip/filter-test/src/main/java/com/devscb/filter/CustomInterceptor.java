package com.devscb.filter;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.HandlerInterceptor;
public class CustomInterceptor implements HandlerInterceptor   {
	 private org.slf4j.Logger logger = LoggerFactory.getLogger(getClass());
	 
	 Map<String, Object> startLogMap = new HashMap<String, Object>();
	 Map<String, Object> endLogMap = new HashMap<String, Object>();
	
	 
	 public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
	   throws Exception {
		  System.out.println("pre handle");
		  return true;
	 }
	 

	 public void postHandle(
	   HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView)
	   throws Exception {
	  System.out.println("post handle");
	 }
}
